# Performance run

Captured 2026-10-03T06:16:08.397Z on `local` (16× AMD Ryzen 7 5700X 8-Core Processor).
Compared against the baseline recorded 2026-09-06T02:12:13.644Z on `local`, tolerance 20%.

| Budget | Owner | Gate verdict | Target verdict (diagnostic in CI) | Observed | Target | Baseline | Drift | Batches / legacy samples | Fixture |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Smoke CI (`smoke-ci`) | Platform | PASS | PASS | 16052.0ms | 180000.0ms | 26913.0ms | -40.4% | 7 | This runner, warm pnpm store |
| App startup (`app-startup`) | Platform | PASS | PASS | 1291.6ms | 2000.0ms | 1006.1ms | +28.4% | 7 | Fresh profile against the Vite DEV server (which pays a per-module transform a production build does not), warm module cache |
| Vault open (`vault-open`) | Platform | PASS | PASS | 1003.5ms | 3000.0ms | 676.7ms | +48.3% | 7 | 200 seeded notes + demo content (budget dataset: 1,000 notes / 100 objects / 20 maps) |
| Scene first render (`scene-first-render`) | Canvas | PASS | PASS | 1485.1ms | 1500.0ms | 1068.3ms | +39.0% | 7 | Cold context with prepared durable campaign, 50 painted widgets / 10 active map bindings (budget dataset: 50 widgets / 10 active bindings) |
| Widget update (`widget-update`) | Canvas | PASS | PASS | 33.5ms | 100.0ms | 16.8ms | +99.4% | 7 | Single accepted command on the demo home scene |
| Map pan/zoom (desktop) (`map-pan-zoom-desktop`) | Maps | PASS | PASS | 59.5fps | 50.0fps | 59.5fps | 0.0% | 7 | world.continent default output (seed runtime-recovery) + 4 layers / 100 additional POIs |
| Map pan/zoom (slim) (`map-pan-zoom-slim`) | Maps | PASS | PASS | 59.5fps | 30.0fps | 59.9fps | +0.6% | 7 | world.continent default output (seed runtime-recovery) + 4 layers / 100 additional POIs |
| Search (`search`) | Search | PASS | PASS | 160.6ms | 250.0ms | 13.0ms | +1135.4% | 7 | 2000 seeded notes + demo content (budget dataset: 10,000 indexed records) |
| Graph indexing (`graph-indexing`) | Graph | PASS | PASS | 346.2ms | 500.0ms | 248.4ms | +39.4% | 7 | One changed note in a 2000-note vault (budget dataset: one changed note in a 10,000-record vault) |
| Sync reconciliation (`sync-reconciliation`) | Sync | PASS | PASS | 1080.2ms | 2000.0ms | 710.7ms | +52.0% | 7 | 200 seeded notes (budget dataset: 1,000 queued operations) |
| Live session update delivery (`live-session-delivery`) | Collaboration | PASS | PASS | 18.7ms | 500.0ms | 16.8ms | +11.3% | 7 | Local player-safe projection of the demo vault; the network hop is NOT included (budget dataset: near-real-time projected session ops) |

0 target breach · 6 regressed · 0 not measured.

