import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
const requireApp=createRequire(process.cwd()+'/apps/gm-react/package.json');
const {chromium}=requireApp('@playwright/test');
const browser=await chromium.launch();
const context=await browser.newContext({viewport:{width:1280,height:800}});
const page=await context.newPage();
await page.addInitScript(()=>localStorage.setItem('dndtools:react:onboarded','gate'));
await page.goto('http://127.0.0.1:19883/#/board');
await page.waitForFunction(()=>window.__rt?.loaded && document.querySelector('[data-testid^="widget-"]'));
await page.evaluate(async () => {
					const rt = window.__rt;
					const sceneId = rt.state.commandCenter.homeSceneId;
					const dispatch = async (type, payload) => {
						const result = await rt.dispatch({ type, actorId: rt.defaultActorId, payload });
						if (result.status !== 'accepted') throw new Error(JSON.stringify(result.rejection));
					};
					const originals = [...rt.state.scenes.scenes[sceneId].widgets];
					if (!originals.length || originals.length > 50)
						throw new Error('Unexpected demo fixture');
					// Demo hydration auto-binds every map tile. Use non-map tiles for the other 40.
					const unbound = originals.filter((widget) => widget.type !== 'map');
					if (!unbound.length) throw new Error('No unbound demo widget types');
					const mapId = Object.keys(rt.state.maps.maps)[0];
					if (!mapId) throw new Error('Demo map absent');
					for (const widget of originals) {
						await dispatch('scene.destroy-widget', { sceneId, widgetInstanceId: widget.id });
					}
					for (let i = 0; i < 50; i++) {
						const source =
							i < 10
								? { type: 'map', version: '1.0.0', configuration: {}, localState: {} }
								: unbound[i % unbound.length];
						await dispatch('scene.add-widget', {
							sceneId,
							widget: {
								type: source.type,
								version: source.version,
								configuration: source.configuration,
								localState: source.localState,
								layout: { x: (i % 5) * 240, y: Math.floor(i / 5) * 180, w: 240, h: 180 },
								binding:
									i < 10
										? {
												source: { entityType: 'map', entityId: mapId },
												mode: 'read',
												requiredCapability: 'viewer',
											}
										: null,
							},
						});
					}
				});
				
const storageState=await context.storageState({indexedDB:true});
await context.close();

const results={plain:[],contained:[]};
for(let batch=0;batch<5;batch++) for(const side of (batch%2?['contained','plain']:['plain','contained'])) {
 const ctx=await browser.newContext({storageState,viewport:{width:1280,height:800}});
 const p=await ctx.newPage();
 if(side==='contained') await p.addInitScript(()=>document.addEventListener('DOMContentLoaded',()=>{
  const style=document.createElement('style');style.textContent='[data-widget-region] { content-visibility: auto; }';document.head.append(style);
 }));
 await p.goto('http://127.0.0.1:19883/#/board',{waitUntil:'domcontentloaded'});
 await p.waitForFunction(()=>document.querySelectorAll('[data-testid="scene-board-bounded"] [data-testid^="widget-"]').length===50 && document.querySelectorAll('[data-testid="map-tile"]').length===10,undefined,{polling:'raf'});
 const elapsed=await p.evaluate(()=>performance.now());results[side].push(elapsed);
 console.log(side,elapsed);await ctx.close();
}
writeFileSync('/tmp/rc-eng-3-2-recovery/containment-experiment.json',JSON.stringify(results,null,2));
await browser.close();
