import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const { chromium } = createRequire(process.cwd() + '/apps/gm-react/package.json')('@playwright/test');
const browser = await chromium.launch();
try {
 const page = await browser.newPage({viewport:{width:1280,height:800}});
 await page.addInitScript(()=>localStorage.setItem('dndtools:react:onboarded','gate'));
 await page.goto('http://127.0.0.1:19883/#/board');
 await page.waitForFunction(()=>window.__rt?.loaded);
 await page.evaluate(async()=>{
  const rt=window.__rt;
  const create=async(title,body)=>{
   const r=await rt.dispatch({type:'content.create-item',actorId:rt.defaultActorId,payload:{kind:'note',title,body,visibility:'player-visible'}});
   if(r.status!=='accepted') throw new Error(JSON.stringify(r.rejection));
  };
  await create('Z Hub','The hub.');
  for(let i=0;i<160;i++) await create('A'+String(i).padStart(3,'0'),'See [[Z Hub]].');
 });
 await page.goto('http://127.0.0.1:19883/#/graph');
 const hub=page.getByTestId('graph-node').and(page.getByRole('button',{name:/^Z Hub,/}));
 await hub.waitFor();await hub.focus();await page.keyboard.press('Enter');
 await page.getByRole('button',{name:'Focus neighborhood',exact:true}).click();
 await page.getByRole('button',{name:'Show full graph',exact:true}).waitFor();
 assert.equal(await hub.count(),1);
 assert.equal(await hub.getAttribute('aria-pressed'),'true');
 assert.equal(await page.getByTestId('graph-node').count(),150);
 assert.equal(await page.getByText('Selected',{exact:true}).count(),1);
 assert.equal(await page.getByRole('button',{name:'Show full graph',exact:true}).isEnabled(),true);
 console.log(JSON.stringify({hubPresent:true,selected:true,inspectorPresent:true,focusActive:true,canvasNodes:150}));
} finally {await browser.close();}
