import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { seedLargeScene } from '<candidate>/scripts/perf/scene-fixture';
const requireApp = createRequire(
	'<candidate>/apps/gm-react/package.json',
);
const { chromium } = requireApp('@playwright/test');
const port = process.argv[2] ?? '19941';
const runs = Number(process.argv[3] ?? '3');
const out = process.argv[4];
const base = `http://localhost:${port}`;
const browser = await chromium.launch();
const init = { content: `(() => {
	window.localStorage.setItem('dndtools:react:onboarded', 'gate');
	performance.setResourceTimingBufferSize(10000);
	const lt = {};
	(window).__lt = lt;
	const tick = () => {
		const now = Math.round(performance.now());
		const rt = (window).__rt;
		if (rt && !lt.rt) lt.rt = now;
		if (!lt.obs && document.body) { lt.obs = now; new MutationObserver(() => { const b = document.querySelector('[data-testid="scene-board-bounded"]'); if (b && !lt.commit && b.querySelectorAll('[data-testid^="widget-"]').length === 50) lt.commit = Math.round(performance.now()); }).observe(document.body, { childList: true, subtree: true }); }
		if (rt?.loaded && !lt.loaded) lt.loaded = now;
		const board = document.querySelector('[data-testid="scene-board-bounded"]');
		if (board && !lt.board) lt.board = now;
		const w = board?.querySelectorAll('[data-testid^="widget-"]').length ?? 0;
		if (w > 0 && !lt.w1) lt.w1 = now;
		if (w === 50 && !lt.w50) lt.w50 = now;
		const m = board?.querySelectorAll('[data-testid="map-tile"]').length ?? 0;
		if (m > 0 && !lt.m1) lt.m1 = now;
		if (m === 10 && !lt.m10) { lt.m10 = now; return; }
		requestAnimationFrame(tick);
	};
	requestAnimationFrame(tick);
})();` };
const setupCtx = await browser.newContext({ baseURL: base, viewport: { width: 1280, height: 800 } });
const setup = await setupCtx.newPage();
await setup.addInitScript(init);
await setup.goto('/#/board');
await setup.locator('[data-testid^="widget-"]').first().waitFor({ state: 'attached', timeout: 60000 });
await setup.evaluate(seedLargeScene);
const storageState = await setupCtx.storageState({ indexedDB: true });
await setupCtx.close();
const results = [];
for (let i = -1; i < runs; i++) {
	const ctx = await browser.newContext({ baseURL: base, storageState, viewport: { width: 1280, height: 800 } });
	const page = await ctx.newPage();
	await page.addInitScript(init);
	const cdp = process.env.PROFILE && i === runs - 1 ? await ctx.newCDPSession(page) : null;
	if (cdp) { await cdp.send('Profiler.enable'); await cdp.send('Profiler.setSamplingInterval', { interval: 200 }); await cdp.send('Profiler.start'); }
	await page.goto('/#/board', { waitUntil: 'domcontentloaded' });
	await page.waitForFunction(
		() => {
			const board = document.querySelector('[data-testid="scene-board-bounded"]');
			return (
				!!board &&
				board.querySelectorAll('[data-testid^="widget-"]').length === 50 &&
				board.querySelectorAll('[data-testid="map-tile"]').length === 10
			);
		},
		undefined,
		{ timeout: 60000, polling: 'raf' },
	);
	const measured = await page.evaluate(() => {
		performance.mark('rc-perf:scene-first-render:painted');
		return performance.measure('rc-perf:scene-first-render', undefined, 'rc-perf:scene-first-render:painted').duration;
	});
	const r = await page.evaluate(() => {
		const total = performance.now();
		const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
		const res = (performance.getEntriesByType('resource') as PerformanceResourceTiming[]).map((e) => ({
			name: e.name.replace(location.origin, ''),
			start: Math.round(e.startTime),
			reqStart: Math.round(e.requestStart),
			resStart: Math.round(e.responseStart),
			end: Math.round(e.responseEnd),
		}));
		const marks = performance.getEntriesByType('mark').map((m) => ({ name: m.name, t: Math.round(m.startTime) }));
		const lt = (window as unknown as { __lt?: unknown }).__lt;
		return { total: Math.round(total), dcl: Math.round(nav.domContentLoadedEventEnd), res, marks, lt };
	});
	if (cdp) { const { profile } = await cdp.send('Profiler.stop'); writeFileSync(process.env.PROFILE!, JSON.stringify({ profile, origin: await page.evaluate(() => performance.timeOrigin) })); }
	await ctx.close();
	if (i >= 0) results.push(r);
	console.log(JSON.stringify({ measured: Math.round(measured), ...(r.lt as object) }));
	const core = r.res.filter((e) => e.name.includes('/packages/core/')).length;
	const src = r.res.filter((e) => e.name.includes('/src/')).length;
	const lastCore = Math.max(...r.res.filter((e) => e.name.includes('/packages/core/')).map((e) => e.end));
	const lastRes = Math.max(...r.res.map((e) => e.end));
	console.log(i, 'total', r.total, 'dcl', r.dcl, 'res', r.res.length, 'core', core, 'app', src, 'lastCore', lastCore, 'lastRes', lastRes);
}
if (out) writeFileSync(out, JSON.stringify(results, null, 1));
await browser.close();
