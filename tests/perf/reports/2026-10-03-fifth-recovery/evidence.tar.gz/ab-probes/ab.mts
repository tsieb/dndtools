// Interleaved A/B of the scene-first-render interval, measured exactly as scripts/perf/capture.ts does.
// Usage: tsx ab.mts <refPort> <candPort> <pairs> <out.json> [throttle]
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { seedLargeScene } from '<candidate>/scripts/perf/scene-fixture';
const requireApp = createRequire(
	'<candidate>/apps/gm-react/package.json',
);
const { chromium } = requireApp('@playwright/test');
const [refPort, candPort, pairsArg, out, throttleArg] = process.argv.slice(2);
const pairs = Number(pairsArg);
const throttle = Number(throttleArg ?? '1');
const browser = await chromium.launch();
const init = { content: `(() => {
	window.localStorage.setItem('dndtools:react:onboarded', 'gate');
	const lt = {}; window.__lt = lt;
	new MutationObserver(() => {
		if (lt.commit) return;
		const b = document.querySelector('[data-testid="scene-board-bounded"]');
		if (b && b.querySelectorAll('[data-testid^="widget-"]').length === 50) lt.commit = Math.round(performance.now());
	}).observe(document, { childList: true, subtree: true });
})();` };
async function prepare(port: string) {
	const ctx = await browser.newContext({ baseURL: `http://localhost:${port}`, viewport: { width: 1280, height: 800 } });
	const page = await ctx.newPage();
	await page.addInitScript(init);
	await page.goto('/#/board');
	await page.locator('[data-testid^="widget-"]').first().waitFor({ state: 'attached', timeout: 60000 });
	await page.evaluate(seedLargeScene);
	const state = await ctx.storageState({ indexedDB: true });
	await ctx.close();
	return state;
}
const states: Record<string, unknown> = { ref: await prepare(refPort), cand: await prepare(candPort) };
const ports: Record<string, string> = { ref: refPort, cand: candPort };
async function sample(side: string) {
	const ctx = await browser.newContext({
		baseURL: `http://localhost:${ports[side]}`,
		storageState: states[side],
		viewport: { width: 1280, height: 800 },
		deviceScaleFactor: 1,
	});
	try {
		const page = await ctx.newPage();
		await page.addInitScript(init);
		if (throttle !== 1) {
			const cdp = await ctx.newCDPSession(page);
			await cdp.send('Emulation.setCPUThrottlingRate', { rate: throttle });
		}
		await page.goto('/#/board', { waitUntil: 'domcontentloaded' });
		await page.waitForFunction(
			() => {
				const rt = (window as unknown as { __rt?: { loaded?: boolean } }).__rt;
				if (!rt?.loaded) return false;
				const board = document.querySelector('[data-testid="scene-board-bounded"]');
				return (
					!!board &&
					board.querySelectorAll('[data-testid^="widget-"]').length === 50 &&
					board.querySelectorAll('[data-testid="map-tile"]').length === 10
				);
			},
			undefined,
			{ timeout: 60000, polling: 'raf' },
		);
		const measured = await page.evaluate(() => {
			performance.mark('p');
			return performance.measure('m', undefined, 'p').duration;
		});
		const commit = await page.evaluate(() => (window as unknown as { __lt: { commit: number } }).__lt.commit);
		return { measured: Math.round(measured), commit };
	} finally {
		await ctx.close();
	}
}
const res: Record<string, { measured: number; commit: number }[]> = { ref: [], cand: [] };
await sample('ref');
await sample('cand');
for (let i = 0; i < pairs; i++) {
	const order = i % 2 ? ['cand', 'ref'] : ['ref', 'cand'];
	for (const side of order) res[side].push(await sample(side));
}
await browser.close();
const med = (xs: number[]) => {
	const s = [...xs].sort((a, b) => a - b);
	return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
};
const summary = Object.fromEntries(
	Object.entries(res).map(([k, v]) => [
		k,
		{ measured: med(v.map((x) => x.measured)), commit: med(v.map((x) => x.commit)), tail: med(v.map((x) => x.measured - x.commit)) },
	]),
);
const diffs = res.cand.map((c, i) => c.measured - res.ref[i].measured);
console.log(JSON.stringify(summary), 'pairedDiffMedian', med(diffs), 'candFaster', diffs.filter((d) => d < 0).length, '/', diffs.length);
writeFileSync(out, JSON.stringify({ res, summary, diffs }, null, 1));
