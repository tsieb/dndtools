// Grade a paired capture's two sides with the harness's own measureCapture.
// Usage: tsx grade.ts <current.json> <reference.json>
import { readFileSync } from 'node:fs';
import { measureCapture } from '<candidate>/scripts/perf/compare';
const [cur, ref] = process.argv.slice(2).map((p) => JSON.parse(readFileSync(p, 'utf8')));
console.log('candidate', cur.commit, 'reference', ref.commit);
const rows = [];
for (const b of cur.budgets) {
	const r = ref.budgets.find((x: { budgetId: string }) => x.budgetId === b.budgetId);
	const mc = measureCapture(b.budgetId, b);
	const mr = measureCapture(b.budgetId, r);
	const batchStats = (cap: { repetitions: number[][] }) =>
		cap.repetitions.map((s) => measureCapture(b.budgetId, { samples: s }).observedValue);
	rows.push({
		budget: b.budgetId,
		candidate: mc.observedValue,
		reference: mr.observedValue,
		target: mc.budget?.metric.target,
		verdict: mc.result,
		refVerdict: mr.result,
		batches: mc.sampleCount,
		candBatches: batchStats(b).join(' '),
		refBatches: r ? batchStats(r).join(' ') : '',
	});
}
console.table(rows.map(({ candBatches, refBatches, ...rest }) => rest));
for (const r of rows) console.log(r.budget, '\n  cand', r.candBatches, '\n  ref ', r.refBatches);
