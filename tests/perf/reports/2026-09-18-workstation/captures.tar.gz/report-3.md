# Performance run

Captured 2026-09-18T21:02:13.813Z on `github-ubuntu-24.04` (16× AMD Ryzen 7 5700X 8-Core Processor).
Compared against the baseline recorded 2026-09-18T21:02:13.813Z on `github-ubuntu-24.04`, tolerance 20%.

| Budget | Owner | Gate verdict | Target verdict (diagnostic in CI) | Observed | Target | Baseline | Drift | Batches / legacy samples | Fixture |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Smoke CI (`smoke-ci`) | Platform | PASS | PASS | 14773.0ms | 180000.0ms | 13917.0ms | +6.2% | 7 | This runner, warm pnpm store |
| App startup (`app-startup`) | Platform | PASS | PASS | 879.3ms | 2000.0ms | 1029.9ms | -14.6% | 7 | Fresh profile against the Vite DEV server (which pays a per-module transform a production build does not), warm module cache |
| Vault open (`vault-open`) | Platform | PASS | PASS | 706.2ms | 3000.0ms | 727.9ms | -3.0% | 7 | 200 seeded notes + demo content (budget dataset: 1,000 notes / 100 objects / 20 maps) |
| Scene first render (`scene-first-render`) | Canvas | PASS | PASS | 1024.6ms | 1500.0ms | 1148.8ms | -10.8% | 7 | Demo-seeded home scene, 7 painted widgets (budget dataset: 50 widgets / 10 active bindings) |
| Widget update (`widget-update`) | Canvas | PASS | PASS | 18.1ms | 100.0ms | 19.6ms | -7.7% | 7 | Single accepted command on the demo home scene |
| Map pan/zoom (desktop) (`map-pan-zoom-desktop`) | Maps | PASS | PASS | 59.9fps | 50.0fps | 59.5fps | -0.6% | 7 | 4 layers / 100 POIs |
| Map pan/zoom (slim) (`map-pan-zoom-slim`) | Maps | PASS | PASS | 59.9fps | 30.0fps | 59.5fps | -0.6% | 7 | 4 layers / 100 POIs |
| Search (`search`) | Search | PASS | PASS | 6.0ms | 250.0ms | 6.0ms | 0.0% | 7 | 200 seeded notes + demo content (budget dataset: 10,000 indexed records) |
| Graph indexing (`graph-indexing`) | Graph | PASS | PASS | 110.6ms | 500.0ms | 115.4ms | -4.2% | 7 | One changed note in a 200-note vault (budget dataset: one changed note in a 10,000-record vault) |
| Sync reconciliation (`sync-reconciliation`) | Sync | PASS | PASS | 696.3ms | 2000.0ms | 697.2ms | -0.1% | 7 | 241 queued operations (200 seeded notes) (budget dataset: 1,000 queued operations) |
| Live session update delivery (`live-session-delivery`) | Collaboration | PASS | PASS | 17.4ms | 500.0ms | 16.8ms | +3.6% | 7 | Local player-safe projection of the demo vault; the network hop is NOT included (budget dataset: near-real-time projected session ops) |

0 target breach (diagnostic) · 0 regressed · 0 not measured.

