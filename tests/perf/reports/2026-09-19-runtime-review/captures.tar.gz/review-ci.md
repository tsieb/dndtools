# Performance run

Captured 2026-09-20T02:28:38.359Z on `local-workstation` (16× AMD Ryzen 7 5700X 8-Core Processor).
Compared against the baseline recorded 2026-09-20T02:28:38.359Z on `local-workstation`, tolerance 20%.

| Budget | Owner | Gate verdict | Target verdict (diagnostic in CI) | Observed | Target | Baseline | Drift | Batches / legacy samples | Fixture |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Smoke CI (`smoke-ci`) | Platform | PASS | PASS | 15244.0ms | 180000.0ms | 14748.0ms | +3.4% | 7 | This runner, warm pnpm store |
| App startup (`app-startup`) | Platform | PASS | PASS | 915.7ms | 2000.0ms | 908.2ms | +0.8% | 7 | Fresh profile against the Vite DEV server (which pays a per-module transform a production build does not), warm module cache |
| Vault open (`vault-open`) | Platform | PASS | PASS | 709.5ms | 3000.0ms | 723.3ms | -1.9% | 7 | 200 seeded notes + demo content (budget dataset: 1,000 notes / 100 objects / 20 maps) |
| Scene first render (`scene-first-render`) | Canvas | PASS | PASS | 1081.4ms | 1500.0ms | 1134.7ms | -4.7% | 7 | Cold context with prepared durable campaign, 50 painted widgets / 10 active map bindings (budget dataset: 50 widgets / 10 active bindings) |
| Widget update (`widget-update`) | Canvas | PASS | PASS | 18.9ms | 100.0ms | 16.8ms | +12.5% | 7 | Single accepted command on the demo home scene |
| Map pan/zoom (desktop) (`map-pan-zoom-desktop`) | Maps | PASS | PASS | 59.5fps | 50.0fps | 59.5fps | 0.0% | 7 | world.continent default output (seed runtime-recovery) + 4 layers / 100 additional POIs |
| Map pan/zoom (slim) (`map-pan-zoom-slim`) | Maps | PASS | PASS | 59.5fps | 30.0fps | 59.5fps | 0.0% | 7 | world.continent default output (seed runtime-recovery) + 4 layers / 100 additional POIs |
| Search (`search`) | Search | PASS | BREACH | 306.7ms | 250.0ms | 270.4ms | +13.4% | 7 | 2000 seeded notes + demo content (budget dataset: 10,000 indexed records) |
| Graph indexing (`graph-indexing`) | Graph | PASS | BREACH | 1209.4ms | 500.0ms | 1221.8ms | -1.0% | 7 | One changed note in a 2000-note vault (budget dataset: one changed note in a 10,000-record vault) |
| Sync reconciliation (`sync-reconciliation`) | Sync | PASS | PASS | 943.7ms | 2000.0ms | 945.7ms | -0.2% | 7 | 241 queued operations (200 seeded notes) (budget dataset: 1,000 queued operations) |
| Live session update delivery (`live-session-delivery`) | Collaboration | PASS | PASS | 17.1ms | 500.0ms | 17.0ms | +0.6% | 7 | Local player-safe projection of the demo vault; the network hop is NOT included (budget dataset: near-real-time projected session ops) |

2 target breach (diagnostic) · 0 regressed · 0 not measured.

