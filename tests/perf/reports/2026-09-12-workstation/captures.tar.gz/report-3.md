# Performance run

Captured 2026-09-12T08:49:57.013Z on `github-ubuntu-24.04` (16× AMD Ryzen 7 5700X 8-Core Processor).
Compared against the baseline recorded 2026-09-12T08:49:57.013Z on `github-ubuntu-24.04`, tolerance 20%.

| Budget | Owner | Gate verdict | Target verdict (diagnostic in CI) | Observed | Target | Baseline | Drift | Batches / legacy samples | Fixture |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Smoke CI (`smoke-ci`) | Platform | PASS | PASS | 20713.0ms | 180000.0ms | 19865.0ms | +4.3% | 7 | This runner, warm pnpm store |
| App startup (`app-startup`) | Platform | PASS | PASS | 1350.0ms | 2000.0ms | 1315.1ms | +2.7% | 7 | Fresh profile against the Vite DEV server (which pays a per-module transform a production build does not), warm module cache |
| Vault open (`vault-open`) | Platform | PASS | PASS | 971.4ms | 3000.0ms | 969.1ms | +0.2% | 7 | 200 seeded notes + demo content (budget dataset: 1,000 notes / 100 objects / 20 maps) |
| Scene first render (`scene-first-render`) | Canvas | PASS | BREACH | 1545.4ms | 1500.0ms | 1471.9ms | +5.0% | 7 | Demo-seeded home scene, 7 painted widgets (budget dataset: 50 widgets / 10 active bindings) |
| Widget update (`widget-update`) | Canvas | PASS | PASS | 33.3ms | 100.0ms | 33.4ms | -0.3% | 7 | Single accepted command on the demo home scene |
| Map pan/zoom (desktop) (`map-pan-zoom-desktop`) | Maps | PASS | PASS | 59.9fps | 50.0fps | 59.5fps | -0.6% | 7 | 4 layers / 100 POIs |
| Map pan/zoom (slim) (`map-pan-zoom-slim`) | Maps | PASS | PASS | 59.5fps | 30.0fps | 59.9fps | +0.6% | 7 | 4 layers / 100 POIs |
| Search (`search`) | Search | PASS | PASS | 13.0ms | 250.0ms | 11.0ms | +18.2% | 7 | 200 seeded notes + demo content (budget dataset: 10,000 indexed records) |
| Graph indexing (`graph-indexing`) | Graph | PASS | PASS | 209.4ms | 500.0ms | 232.6ms | -10.0% | 7 | One changed note in a 200-note vault (budget dataset: one changed note in a 10,000-record vault) |
| Sync reconciliation (`sync-reconciliation`) | Sync | PASS | PASS | 1261.4ms | 2000.0ms | 1229.5ms | +2.6% | 7 | 241 queued operations (200 seeded notes) (budget dataset: 1,000 queued operations) |
| Live session update delivery (`live-session-delivery`) | Collaboration | PASS | PASS | 18.2ms | 500.0ms | 19.4ms | -6.2% | 7 | Local player-safe projection of the demo vault; the network hop is NOT included (budget dataset: near-real-time projected session ops) |

1 target breach (diagnostic) · 0 regressed · 0 not measured.

